import {Shape, Circle, Rectangle, Triangle} from './shapes';

/**
 * The CAD drawing model currently being created
 */
export class Model {
  private shapes:Shape[] = [];

  constructor() {}

  getShapes():Shape[] {
    return this.shapes;    
  }

  getShapeAt(x:number, y:number):Shape{
    let found:Shape;
    for(let shape of this.shapes){
      if(shape.contains(x,y)){
        found = shape;
      }
    }
    return found; //return last shape
  }

  getShapeIndexAt(x:number, y:number):number {
    let index = 0;
    for(let shape of this.shapes){
      if(shape.contains(x,y)){
        break;
      }
      index++;
    }
    return index; //return last shape
  }

  drawShape(action:string, x:number, y:number) {
    let shape;
    if(action === 'rectangle') {
      shape = new Rectangle(x, y, 60, 30);
    } else if (action === 'circle') {
      shape = new Circle(x, y, 25);
    } else if(action === 'triangle') {
      shape = new Triangle(x, y, x + 30, y - 30, x  + 60, y);
    }
    let canvas = <HTMLCanvasElement>$('#graphics-view canvas')[0];
    let brush = canvas.getContext('2d');
    shape.draw(brush);
    this.shapes.push(shape);
  }

  showText() {
    let textArea = document.getElementsByClassName('form-control');
    textArea[0].innerHTML = '';
     for(let i = 0; i < this.shapes.length; i++) {
        textArea[0].innerHTML += JSON.stringify(this.shapes[i]) + '\n';  
     }
  }

  updateText() {
    let textArea = document.getElementsByClassName('form-control');
    for(let i = 0; i < this.shapes.length; i++) {
        //this.updateShape(/*JSON.parse() something */); //get each element from each line and update shapes accordingle
     }
  }

  updateShape(x: number, y:number, selected:Shape) {
    selected.setPosition(x, y);
  }

  deleteShape(index:number) {
    this.shapes.splice(index, 1);
  }
}
